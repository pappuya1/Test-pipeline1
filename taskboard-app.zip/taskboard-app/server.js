// server.js — TaskBoard backend (Node.js + Express + MySQL)
// The course capstone app. Reads/writes the `tasks` table from Module 09.
//
// The 7 DevOps questions, answered for this app:
//   1. Language/runtime : Node.js (>=18)
//   2. Build            : npm install  (no compile step)
//   3. Artifact         : this folder + node_modules
//   4. Start command    : node server.js   (or: npm start)
//   5. Port             : 3000  (set by PORT in .env)
//   6. Config           : .env  (DB host/user/password/name) — NEVER hardcoded
//   7. Health           : GET /health

require('dotenv').config();          // load secrets from .env into process.env
const express = require('express');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();
app.use(express.json());             // understand JSON request bodies
app.use(express.static(path.join(__dirname, 'public')));  // serve the HTML page

// --- Config comes from environment variables (Q6). Never hardcode secrets. ---
const PORT = process.env.PORT || 3000;
const pool = mysql.createPool({
  host:     process.env.DB_HOST || '127.0.0.1',
  user:     process.env.DB_USER || 'taskboard_app',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'taskboard',
  waitForConnections: true,
  connectionLimit: 5
});

// --- Route 1: list all tasks ---
app.get('/api/tasks', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, title, done, created_at FROM tasks ORDER BY id DESC'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Route 2: add a task ---
app.post('/api/tasks', async (req, res) => {
  const title = (req.body.title || '').trim();
  if (!title) return res.status(400).json({ error: 'title is required' });
  try {
    const [result] = await pool.query(
      'INSERT INTO tasks (title) VALUES (?)', [title]   // ? = safe placeholder
    );
    res.status(201).json({ id: result.insertId, title, done: 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Route 3: mark a task done ---
app.put('/api/tasks/:id/done', async (req, res) => {
  try {
    const [result] = await pool.query(
      'UPDATE tasks SET done = 1 WHERE id = ?', [req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'not found' });
    res.json({ id: Number(req.params.id), done: 1 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Health check (Q7): is the app up AND can it reach the database? ---
app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');                 // ping the database
    res.json({ status: 'ok', db: 'up' });
  } catch (err) {
    res.status(503).json({ status: 'error', db: 'down', detail: err.message });
  }
});

app.listen(PORT, () => console.log(`TaskBoard running on http://localhost:${PORT}`));
